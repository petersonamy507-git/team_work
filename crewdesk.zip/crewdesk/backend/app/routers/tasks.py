from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func, or_
from sqlalchemy.orm import Session

from .. import models, schemas
from ..database import get_db
from ..helpers import get_or_404, apply, log, notify
from ..security import current_user

router = APIRouter(prefix="/api", tags=["tasks"])


def task_full(db, t):
    subtasks = db.scalars(select(models.Task).where(models.Task.parent_id == t.id).order_by(models.Task.position,
                                                                                            models.Task.id)).all()
    comments = db.scalars(select(models.Comment).where(models.Comment.task_id == t.id)
                          .order_by(models.Comment.id)).all()
    logged = db.scalar(select(func.coalesce(func.sum(models.TimeEntry.minutes), 0)).where(
        models.TimeEntry.task_id == t.id)) or 0
    files = db.scalars(select(models.FileItem).where(models.FileItem.task_id == t.id)).all()
    return schemas.task_out(t, {
        "subtasks": [schemas.task_out(s) for s in subtasks],
        "comments": [{"id": c.id, "body": c.body, "user": schemas.user_brief(c.user),
                      "created_at": schemas.d(c.created_at)} for c in comments],
        "logged_minutes": int(logged),
        "files": [{"id": f.id, "name": f.original_name, "size": f.size} for f in files],
    })


@router.get("/tasks")
def list_tasks(assignee: str | None = None, project_id: int | None = None, status: str = "open",
               due: str | None = None, created_by: str | None = None, q: str | None = None,
               priority: str | None = None, limit: int = 500,
               db: Session = Depends(get_db), user=Depends(current_user)):
    """Filters: assignee=me|<id>|none, status=open|completed|all, due=late|today|upcoming|nodate|week,
    created_by=me (tasks I created for others)."""
    stmt = select(models.Task).where(models.Task.parent_id.is_(None))
    today = date.today()
    if assignee == "me":
        stmt = stmt.where(models.Task.assignee_id == user.id)
    elif assignee == "none":
        stmt = stmt.where(models.Task.assignee_id.is_(None))
    elif assignee:
        stmt = stmt.where(models.Task.assignee_id == int(assignee))
    if created_by == "me":
        stmt = stmt.where(models.Task.created_by_id == user.id,
                          or_(models.Task.assignee_id.is_(None), models.Task.assignee_id != user.id))
    if project_id:
        stmt = stmt.where(models.Task.project_id == project_id)
    if status == "open":
        stmt = stmt.where(models.Task.status != "completed")
    elif status == "completed":
        stmt = stmt.where(models.Task.status == "completed")
    if priority:
        stmt = stmt.where(models.Task.priority == priority)
    if due == "late":
        stmt = stmt.where(models.Task.due_date < today)
    elif due == "today":
        stmt = stmt.where(models.Task.due_date == today)
    elif due == "upcoming":
        stmt = stmt.where(models.Task.due_date > today)
    elif due == "nodate":
        stmt = stmt.where(models.Task.due_date.is_(None))
    elif due == "week":
        stmt = stmt.where(models.Task.due_date >= today, models.Task.due_date <= today + timedelta(days=7))
    if q:
        stmt = stmt.where(models.Task.title.ilike(f"%{q}%"))
    stmt = stmt.order_by(models.Task.due_date.is_(None), models.Task.due_date, models.Task.id).limit(limit)
    return [schemas.task_out(t) for t in db.scalars(stmt).all()]


@router.post("/projects/{pid}/tasks")
def create_task(pid: int, body: schemas.TaskIn, db: Session = Depends(get_db), user=Depends(current_user)):
    p = get_or_404(db, models.Project, pid, "Project")
    if not body.title:
        raise HTTPException(400, "Title is required")
    data = {k: v for k, v in body.model_dump().items() if v is not None}
    if not data.get("tasklist_id") and not data.get("parent_id"):
        tl = db.scalar(select(models.TaskList).where(models.TaskList.project_id == pid)
                       .order_by(models.TaskList.position))
        if not tl:
            tl = models.TaskList(project_id=pid, name="General tasks")
            db.add(tl)
            db.flush()
        data["tasklist_id"] = tl.id
    if data.get("parent_id"):
        parent = get_or_404(db, models.Task, data["parent_id"], "Parent task")
        data.setdefault("tasklist_id", parent.tasklist_id)
    if not data.get("column_id"):
        col = db.scalar(select(models.BoardColumn).where(models.BoardColumn.project_id == pid)
                        .order_by(models.BoardColumn.position))
        if col:
            data["column_id"] = col.id
    pos = db.scalar(select(func.coalesce(func.max(models.Task.position), -1)).where(
        models.Task.tasklist_id == data.get("tasklist_id"))) + 1
    t = models.Task(project_id=pid, created_by_id=user.id, position=pos, **data)
    db.add(t)
    db.flush()
    log(db, user, f"added task {t.title}", pid)
    notify(db, t.assignee_id, user, f"{user.name} assigned you \"{t.title}\" in {p.name}", f"/tasks/{t.id}", "task")
    db.commit()
    db.refresh(t)
    return schemas.task_out(t)


@router.get("/tasks/{tid}")
def get_task(tid: int, db: Session = Depends(get_db), user=Depends(current_user)):
    return task_full(db, get_or_404(db, models.Task, tid, "Task"))


@router.patch("/tasks/{tid}")
def update_task(tid: int, body: schemas.TaskIn, db: Session = Depends(get_db), user=Depends(current_user)):
    t = get_or_404(db, models.Task, tid, "Task")
    data = body.model_dump(exclude_unset=True)
    old_assignee = t.assignee_id
    old_status = t.status
    # keep status and board column in sync
    if "column_id" in data and data["column_id"]:
        cols = db.scalars(select(models.BoardColumn).where(models.BoardColumn.project_id == t.project_id)
                          .order_by(models.BoardColumn.position)).all()
        if cols and data["column_id"] == cols[-1].id and "status" not in data:
            data["status"] = "completed"
        elif cols and data["column_id"] != cols[0].id and "status" not in data and t.status == "new":
            data["status"] = "in_progress"
        elif "status" not in data and t.status == "completed":
            data["status"] = "in_progress"
    apply(t, data)
    if "status" in data:
        if data["status"] == "completed" and old_status != "completed":
            t.completed_at = datetime.utcnow()
            t.progress = 100
            log(db, user, f"completed task {t.title}", t.project_id)
            notify(db, t.created_by_id, user, f"{user.name} completed \"{t.title}\"", f"/tasks/{t.id}", "task")
            if "column_id" not in data:
                last = db.scalar(select(models.BoardColumn).where(models.BoardColumn.project_id == t.project_id)
                                 .order_by(models.BoardColumn.position.desc()))
                if last:
                    t.column_id = last.id
        elif data["status"] != "completed" and old_status == "completed":
            t.completed_at = None
            if "column_id" not in data:
                first = db.scalar(select(models.BoardColumn).where(models.BoardColumn.project_id == t.project_id)
                                  .order_by(models.BoardColumn.position))
                if first:
                    t.column_id = first.id
    if "assignee_id" in data and data["assignee_id"] != old_assignee:
        notify(db, data["assignee_id"], user, f"{user.name} assigned you \"{t.title}\"", f"/tasks/{t.id}", "task")
    db.commit()
    db.refresh(t)
    return task_full(db, t)


@router.post("/tasks/{tid}/move")
def move_task(tid: int, column_id: int | None = None, tasklist_id: int | None = None, position: int = 0,
              db: Session = Depends(get_db), user=Depends(current_user)):
    """Drag and drop: move to a board column or task list at a position."""
    t = get_or_404(db, models.Task, tid, "Task")
    if column_id is not None:
        siblings = db.scalars(select(models.Task).where(models.Task.column_id == column_id, models.Task.id != tid)
                              .order_by(models.Task.position, models.Task.id)).all()
        update_task(tid, schemas.TaskIn(column_id=column_id), db, user)
    else:
        siblings = db.scalars(select(models.Task).where(models.Task.tasklist_id == tasklist_id,
                                                        models.Task.id != tid)
                              .order_by(models.Task.position, models.Task.id)).all()
        t.tasklist_id = tasklist_id
    siblings.insert(max(0, min(position, len(siblings))), t)
    for i, s in enumerate(siblings):
        s.position = i
    db.commit()
    return {"ok": True}


@router.delete("/tasks/{tid}")
def delete_task(tid: int, db: Session = Depends(get_db), user=Depends(current_user)):
    t = get_or_404(db, models.Task, tid, "Task")
    log(db, user, f"deleted task {t.title}", t.project_id)
    db.delete(t)
    db.commit()
    return {"ok": True}


@router.post("/tasks/{tid}/comments")
def add_comment(tid: int, body: schemas.CommentIn, db: Session = Depends(get_db), user=Depends(current_user)):
    t = get_or_404(db, models.Task, tid, "Task")
    db.add(models.Comment(task_id=tid, user_id=user.id, body=body.body))
    for uid in {t.assignee_id, t.created_by_id}:
        notify(db, uid, user, f"{user.name} commented on \"{t.title}\"", f"/tasks/{t.id}", "comment")
    db.commit()
    return task_full(db, t)


@router.delete("/comments/{cid}")
def delete_comment(cid: int, db: Session = Depends(get_db), user=Depends(current_user)):
    c = get_or_404(db, models.Comment, cid, "Comment")
    if c.user_id != user.id and user.role != "admin":
        raise HTTPException(403, "Not allowed")
    db.delete(c)
    db.commit()
    return {"ok": True}
