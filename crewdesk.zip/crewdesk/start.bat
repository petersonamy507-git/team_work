@echo off
echo Starting Crewdesk: API on http://localhost:8000 and app on http://localhost:5173
start "Crewdesk API" cmd /k "cd /d %~dp0backend && .venv\Scripts\activate && uvicorn app.main:app --reload --port 8000"
start "Crewdesk Web" cmd /k "cd /d %~dp0frontend && npm run dev"
timeout /t 5 >nul
start http://localhost:5173
