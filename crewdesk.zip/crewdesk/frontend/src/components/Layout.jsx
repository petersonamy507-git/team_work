import { useEffect, useState, useRef } from 'react'
import { NavLink, Outlet, useNavigate } from 'react-router-dom'
import {
  Home, CheckSquare, Inbox, Folder, Clock, Users, BarChart3, Flag, CalendarDays, Building2, Activity,
  Plus, Search, LogOut, ChevronsLeft, ChevronsRight, Star, Settings, ListChecks, MessageSquare, FolderPlus, Timer,
} from 'lucide-react'
import { useAuth } from '../lib/auth'
import { useUi } from '../lib/ui-context'
import { api } from '../lib/api'
import { Avatar, Menu, Toast } from './ui'
import TaskDrawer from './TaskDrawer'
import QuickAdd from './QuickAdd'

const NAV = [
  { to: '/', icon: Home, label: 'Home', end: true },
  { to: '/my-work', icon: CheckSquare, label: 'My work' },
  { to: '/inbox', icon: Inbox, label: 'Inbox', badge: true },
  { section: 'Manage' },
  { to: '/projects', icon: Folder, label: 'Projects' },
  { to: '/tasks', icon: ListChecks, label: 'Tasks' },
  { to: '/milestones', icon: Flag, label: 'Milestones' },
  { to: '/calendar', icon: CalendarDays, label: 'Calendar' },
  { to: '/time', icon: Clock, label: 'Time' },
  { section: 'Team' },
  { to: '/people', icon: Users, label: 'People' },
  { to: '/clients', icon: Building2, label: 'Clients' },
  { section: 'Insights' },
  { to: '/reports', icon: BarChart3, label: 'Reports' },
  { to: '/activity', icon: Activity, label: 'Activity' },
]

function Palette() {
  const { paletteOpen, setPaletteOpen, openTask } = useUi()
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [r, setR] = useState(null)
  const timer = useRef()
  useEffect(() => {
    if (!paletteOpen) { setQ(''); setR(null) }
  }, [paletteOpen])
  useEffect(() => {
    clearTimeout(timer.current)
    if (q.trim().length < 2) return setR(null)
    timer.current = setTimeout(() => api.get(`/search?q=${encodeURIComponent(q)}`).then(setR), 200)
  }, [q])
  if (!paletteOpen) return null
  const go = (fn) => { setPaletteOpen(false); fn() }
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && setPaletteOpen(false)} onKeyDown={(e) => e.key === 'Escape' && setPaletteOpen(false)}>
      <div className="palette">
        <input autoFocus placeholder="Search projects, tasks, people, messages…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="results">
          {!r && <div className="muted small" style={{ padding: 10 }}>Type at least 2 characters</div>}
          {r && !r.projects.length && !r.tasks.length && !r.people.length && !r.messages.length && <div className="muted small" style={{ padding: 10 }}>No results</div>}
          {r?.projects.length > 0 && <div className="group">Projects</div>}
          {r?.projects.map((p) => <div key={'p' + p.id} className="item" onClick={() => go(() => navigate(`/projects/${p.id}`))}><span className="dot" style={{ background: p.color }} />{p.name}</div>)}
          {r?.tasks.length > 0 && <div className="group">Tasks</div>}
          {r?.tasks.map((t) => <div key={'t' + t.id} className="item" onClick={() => go(() => openTask(t.id))}><CheckSquare size={15} />{t.title}<span className="muted small" style={{ marginLeft: 'auto' }}>{t.project_name}</span></div>)}
          {r?.people.length > 0 && <div className="group">People</div>}
          {r?.people.map((p) => <div key={'u' + p.id} className="item" onClick={() => go(() => navigate(`/people/${p.id}`))}><Avatar user={p} size={22} />{p.name}</div>)}
          {r?.messages.length > 0 && <div className="group">Messages</div>}
          {r?.messages.map((m) => <div key={'m' + m.id} className="item" onClick={() => go(() => navigate(`/projects/${m.project_id}/messages/${m.id}`))}><MessageSquare size={15} />{m.title}</div>)}
        </div>
      </div>
    </div>
  )
}

export default function Layout() {
  const { user, logout } = useAuth()
  const { setQuickAdd, setPaletteOpen, unread, projects, toast, notify } = useUi()
  const [collapsed, setCollapsed] = useState(() => localStorage.getItem('cd_side') === '1')
  const navigate = useNavigate()

  useEffect(() => {
    const k = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPaletteOpen(true) }
    }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [setPaletteOpen])

  const toggle = () => { localStorage.setItem('cd_side', collapsed ? '0' : '1'); setCollapsed(!collapsed) }
  const starred = projects.filter((p) => p.is_starred)

  return (
    <div className="app">
      <aside className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
        <div className="side-top"><img src="/logo.svg" alt="" /><span className="label">Crewdesk</span></div>
        <div className="side-scroll">
          <Menu trigger={<button className="quick-add"><Plus size={16} /><span className="label">Quick add</span></button>}>
            <button onClick={() => setQuickAdd('task')}><CheckSquare size={15} />Task</button>
            <button onClick={() => setQuickAdd('project')}><FolderPlus size={15} />Project</button>
            <button onClick={() => setQuickAdd('time')}><Timer size={15} />Time entry</button>
            <button onClick={() => setQuickAdd('message')}><MessageSquare size={15} />Message</button>
          </Menu>
          {NAV.map((n, i) => n.section ? <div className="side-section" key={i}>{n.section}</div> : (
            <NavLink key={n.to} to={n.to} end={n.end} className={({ isActive }) => `side-link ${isActive ? 'active' : ''}`} title={n.label}>
              <n.icon size={18} /><span className="label">{n.label}</span>
              {n.badge && unread > 0 && <span className="badge red">{unread}</span>}
            </NavLink>
          ))}
          {starred.length > 0 && <div className="side-section">Starred projects</div>}
          {!collapsed && starred.map((p) => (
            <NavLink key={p.id} to={`/projects/${p.id}`} className="side-project"><span className="dot" style={{ background: p.color }} /><span className="ellipsis">{p.name}</span></NavLink>
          ))}
        </div>
        <div className="side-bottom">
          <button className="side-link" style={{ border: 0, background: 'none', width: '100%' }} onClick={toggle}>
            {collapsed ? <ChevronsRight size={18} /> : <ChevronsLeft size={18} />}<span className="label">Collapse</span>
          </button>
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <button className="search-btn" onClick={() => setPaletteOpen(true)}><Search size={16} />Search<kbd>Ctrl K</kbd></button>
          <Menu trigger={<button className="icon-btn" style={{ width: 'auto', gap: 8, padding: '0 6px' }}><Avatar user={user} size={30} /></button>}>
            <div style={{ padding: '8px 10px' }}><b>{user.name}</b><div className="muted small">{user.email}</div></div>
            <button onClick={() => navigate('/settings')}><Settings size={15} />Profile and settings</button>
            <button onClick={() => { logout(); navigate('/login') }}><LogOut size={15} />Sign out</button>
          </Menu>
        </header>
        <main className="content"><Outlet /></main>
      </div>
      <TaskDrawer />
      <QuickAdd />
      <Palette />
      {toast && <Toast text={toast} onDone={() => notify(null)} />}
    </div>
  )
}
