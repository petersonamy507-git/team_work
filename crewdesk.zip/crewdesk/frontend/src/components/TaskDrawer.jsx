import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { X, Trash2, Clock, Paperclip, Send, Plus } from 'lucide-react'
import { api } from '../lib/api'
import { useUi } from '../lib/ui-context'
import { fmtMinutes, timeAgo, parseDuration, todayISO } from '../lib/format'
import { Avatar } from './ui'
import TaskRow, { CheckButton } from './TaskRow'

export default function TaskDrawer() {
  const { taskId, openTask, people, refresh, notify } = useUi()
  const [task, setTask] = useState(null)
  const [comment, setComment] = useState('')
  const [sub, setSub] = useState('')
  const [lists, setLists] = useState([])
  const [time, setTime] = useState({ open: false, dur: '', desc: '' })

  const load = () => api.get(`/tasks/${taskId}`).then(setTask)

  useEffect(() => {
    if (!taskId) return setTask(null)
    load()
    const k = (e) => e.key === 'Escape' && openTask(null)
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [taskId])

  useEffect(() => {
    if (task) api.get(`/projects/${task.project_id}/tasklists?include_completed=true`).then(setLists)
  }, [task?.project_id])

  if (!taskId) return null
  const close = () => openTask(null)

  const save = async (patch) => {
    const t = await api.patch(`/tasks/${taskId}`, patch)
    setTask(t)
    refresh()
  }
  const del = async () => {
    if (!confirm('Delete this task?')) return
    await api.del(`/tasks/${taskId}`)
    notify('Task deleted')
    close()
    refresh()
  }
  const addComment = async (e) => {
    e.preventDefault()
    if (!comment.trim()) return
    setTask(await api.post(`/tasks/${taskId}/comments`, { body: comment }))
    setComment('')
  }
  const addSub = async (e) => {
    e.preventDefault()
    if (!sub.trim()) return
    await api.post(`/projects/${task.project_id}/tasks`, { title: sub, parent_id: task.id })
    setSub('')
    load()
  }
  const logTime = async (e) => {
    e.preventDefault()
    const minutes = parseDuration(time.dur)
    if (!minutes) return
    await api.post('/time', { project_id: task.project_id, task_id: task.id, date: todayISO(), minutes, description: time.desc })
    setTime({ open: false, dur: '', desc: '' })
    notify(`Logged ${fmtMinutes(minutes)}`)
    load()
    refresh()
  }
  const upload = async (e) => {
    const f = e.target.files[0]
    if (!f) return
    const fd = new FormData()
    fd.append('file', f)
    fd.append('task_id', task.id)
    await api.upload(`/projects/${task.project_id}/files`, fd)
    load()
  }

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && close()}>
      <div className="drawer">
        {!task ? <div className="drawer-body">Loading…</div> : (
          <>
            <div className="drawer-head">
              <CheckButton task={task} onChange={load} />
              <span className="muted small">
                <Link to={`/projects/${task.project_id}/tasks`} onClick={close}>{task.project_name}</Link>
                {task.tasklist_name && <> / {task.tasklist_name}</>}
              </span>
              <span style={{ flex: 1 }} />
              <button className="icon-btn" title="Delete" onClick={del}><Trash2 size={17} /></button>
              <button className="icon-btn" onClick={close}><X size={18} /></button>
            </div>
            <div className="drawer-body">
              <input className="title-input" defaultValue={task.title} key={task.id + task.title}
                onBlur={(e) => e.target.value.trim() && e.target.value !== task.title && save({ title: e.target.value.trim() })} />
              <div className="props">
                <span className="k">Assignee</span>
                <select className="select" value={task.assignee?.id || ''} onChange={(e) => save({ assignee_id: e.target.value ? +e.target.value : null })}>
                  <option value="">Anyone</option>
                  {people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
                <span className="k">Status</span>
                <select className="select" value={task.status} onChange={(e) => save({ status: e.target.value })}>
                  <option value="new">To do</option>
                  <option value="in_progress">In progress</option>
                  <option value="completed">Completed</option>
                </select>
                <span className="k">Task list</span>
                <select className="select" value={task.tasklist_id || ''} onChange={(e) => save({ tasklist_id: +e.target.value })}>
                  {lists.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
                </select>
                <span className="k">Start date</span>
                <input type="date" className="input" value={task.start_date || ''} onChange={(e) => save({ start_date: e.target.value || null })} />
                <span className="k">Due date</span>
                <input type="date" className="input" value={task.due_date || ''} onChange={(e) => save({ due_date: e.target.value || null })} />
                <span className="k">Priority</span>
                <select className="select" value={task.priority} onChange={(e) => save({ priority: e.target.value })}>
                  <option value="none">None</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
                </select>
                <span className="k">Estimated time</span>
                <input className="input" placeholder="e.g. 2h 30m" defaultValue={task.estimate_minutes ? fmtMinutes(task.estimate_minutes) : ''} key={'e' + task.id}
                  onBlur={(e) => save({ estimate_minutes: parseDuration(e.target.value) || null })} />
                <span className="k">Progress</span>
                <span className="row"><input type="range" min="0" max="100" step="10" value={task.progress} onChange={(e) => setTask({ ...task, progress: +e.target.value })} onMouseUp={(e) => save({ progress: +e.target.value })} style={{ flex: 1 }} /> {task.progress}%</span>
                <span className="k">Tags</span>
                <input className="input" placeholder="comma separated" defaultValue={task.tags.join(', ')} key={'t' + task.id}
                  onBlur={(e) => save({ tags: e.target.value })} />
                <span className="k">Logged time</span>
                <span className="row">
                  <span>{fmtMinutes(task.logged_minutes)}{task.estimate_minutes ? ` of ${fmtMinutes(task.estimate_minutes)}` : ''}</span>
                  <button className="btn sm" onClick={() => setTime({ ...time, open: !time.open })}><Clock size={14} />Log time</button>
                </span>
              </div>
              {time.open && (
                <form className="row card" style={{ padding: 10, marginBottom: 16 }} onSubmit={logTime}>
                  <input className="input" style={{ width: 110 }} placeholder="1h 30m" value={time.dur} onChange={(e) => setTime({ ...time, dur: e.target.value })} autoFocus />
                  <input className="input" placeholder="What did you do?" value={time.desc} onChange={(e) => setTime({ ...time, desc: e.target.value })} />
                  <button className="btn primary">Log</button>
                </form>
              )}
              <h3 style={{ marginBottom: 8 }}>Description</h3>
              <textarea className="textarea" placeholder="Add a description…" defaultValue={task.description || ''} key={'d' + task.id}
                onBlur={(e) => e.target.value !== (task.description || '') && save({ description: e.target.value })} />

              <h3 style={{ margin: '20px 0 8px' }}>Subtasks</h3>
              <div className="card">
                {task.subtasks.map((s) => <TaskRow key={s.id} task={s} onChange={load} />)}
                <form className="add-task-inline" onSubmit={addSub}>
                  <Plus size={16} className="muted" />
                  <input placeholder="Add a subtask" value={sub} onChange={(e) => setSub(e.target.value)} />
                </form>
              </div>

              <h3 style={{ margin: '20px 0 8px' }}>Files</h3>
              <div className="row" style={{ flexWrap: 'wrap', marginBottom: 8 }}>
                {task.files.map((f) => (
                  <button key={f.id} className="pill" style={{ border: 0 }} onClick={() => api.download(`/files/${f.id}/download`, f.name)}>
                    <Paperclip size={12} />{f.name}
                  </button>
                ))}
                <label className="btn sm"><Paperclip size={14} />Attach<input type="file" hidden onChange={upload} /></label>
              </div>

              <h3 style={{ margin: '20px 0 12px' }}>Comments</h3>
              {task.comments.map((c) => (
                <div className="comment" key={c.id}>
                  <Avatar user={c.user} />
                  <div className="bubble">
                    <div className="who">{c.user?.name}<span className="when">{timeAgo(c.created_at)}</span></div>
                    <div className="pre">{c.body}</div>
                  </div>
                </div>
              ))}
              <form className="row" onSubmit={addComment}>
                <input className="input" placeholder="Write a comment…" value={comment} onChange={(e) => setComment(e.target.value)} />
                <button className="btn primary"><Send size={14} /></button>
              </form>
              <p className="muted small" style={{ marginTop: 20 }}>Created by {task.created_by?.name || 'someone'} {timeAgo(task.created_at)}</p>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
