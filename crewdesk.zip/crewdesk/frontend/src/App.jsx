import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './lib/auth'
import { UiProvider } from './lib/ui-context'
import Layout from './components/Layout'
import { Login, Register } from './pages/Auth'
import HomePage from './pages/Home'
import MyWork from './pages/MyWork'
import InboxPage from './pages/Inbox'
import Projects from './pages/Projects'
import ProjectLayout, { ProjectOverview, ProjectTasks, ProjectBoard, ProjectTable, ProjectMilestones, ProjectMessages, MessageDetail, ProjectFiles, ProjectTime, ProjectPeople, ProjectActivity } from './pages/Project'
import AllTasks from './pages/AllTasks'
import Milestones from './pages/Milestones'
import CalendarPage from './pages/Calendar'
import TimePage from './pages/Time'
import People, { PersonDetail } from './pages/People'
import Clients from './pages/Clients'
import Reports from './pages/Reports'
import ActivityPage from './pages/Activity'
import SettingsPage from './pages/Settings'

function Protected({ children }) {
  const { user, loading } = useAuth()
  if (loading) return <div className="empty">Loading…</div>
  if (!user) return <Navigate to="/login" replace />
  return <UiProvider>{children}</UiProvider>
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route element={<Protected><Layout /></Protected>}>
        <Route index element={<HomePage />} />
        <Route path="my-work" element={<MyWork />} />
        <Route path="inbox" element={<InboxPage />} />
        <Route path="projects" element={<Projects />} />
        <Route path="projects/:pid" element={<ProjectLayout />}>
          <Route index element={<ProjectOverview />} />
          <Route path="tasks" element={<ProjectTasks />} />
          <Route path="board" element={<ProjectBoard />} />
          <Route path="table" element={<ProjectTable />} />
          <Route path="milestones" element={<ProjectMilestones />} />
          <Route path="messages" element={<ProjectMessages />} />
          <Route path="messages/:mid" element={<MessageDetail />} />
          <Route path="files" element={<ProjectFiles />} />
          <Route path="time" element={<ProjectTime />} />
          <Route path="people" element={<ProjectPeople />} />
          <Route path="activity" element={<ProjectActivity />} />
        </Route>
        <Route path="tasks" element={<AllTasks />} />
        <Route path="tasks/:tid" element={<AllTasks />} />
        <Route path="milestones" element={<Milestones />} />
        <Route path="calendar" element={<CalendarPage />} />
        <Route path="time" element={<TimePage />} />
        <Route path="people" element={<People />} />
        <Route path="people/:id" element={<PersonDetail />} />
        <Route path="clients" element={<Clients />} />
        <Route path="reports" element={<Reports />} />
        <Route path="activity" element={<ActivityPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  )
}
