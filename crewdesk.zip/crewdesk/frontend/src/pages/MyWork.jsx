import { useState } from 'react'
import { CheckSquare, Plus } from 'lucide-react'
import { useData, useUi } from '../lib/ui-context'
import { todayISO } from '../lib/format'
import { Empty, Loading } from '../components/ui'
import TaskRow from '../components/TaskRow'
import BoardByStatus from '../components/StatusBoard'

export default function MyWork() {
  const { setQuickAdd } = useUi()
  const [view, setView] = useState('list')
  const [status, setStatus] = useState('open')
  const { data } = useData(`/tasks?assignee=me&status=${status}`, [status])
  if (!data) return <div className="page"><Loading /></div>
  const t = todayISO()
  const in7 = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10)
  const groups = status === 'completed' ? [['Completed', data]] : [
    ['Late', data.filter((x) => x.due_date && x.due_date < t)],
    ['Today', data.filter((x) => x.due_date === t)],
    ['Next 7 days', data.filter((x) => x.due_date > t && x.due_date <= in7)],
    ['Later', data.filter((x) => x.due_date > in7)],
    ['No due date', data.filter((x) => !x.due_date)],
  ]
  return (
    <div className="page">
      <div className="page-head">
        <h1>My work</h1>
        <span className="spacer" />
        <div className="seg">
          <button className={status === 'open' ? 'active' : ''} onClick={() => setStatus('open')}>Open</button>
          <button className={status === 'completed' ? 'active' : ''} onClick={() => setStatus('completed')}>Completed</button>
        </div>
        <div className="seg">
          <button className={view === 'list' ? 'active' : ''} onClick={() => setView('list')}>List</button>
          <button className={view === 'board' ? 'active' : ''} onClick={() => setView('board')}>Board</button>
        </div>
        <button className="btn primary" onClick={() => setQuickAdd('task')}><Plus size={16} />Add task</button>
      </div>
      {data.length === 0 ? <div className="card"><Empty icon={CheckSquare} title="Nothing here" text="Tasks assigned to you show up here" /></div> :
        view === 'board' ? <BoardByStatus tasks={data} /> : groups.filter(([, items]) => items.length).map(([label, items]) => (
          <div className="card list-block" key={label}>
            <div className="list-head"><h3 style={{ color: label === 'Late' ? 'var(--danger)' : undefined }}>{label}</h3><span className="badge grey">{items.length}</span></div>
            {items.map((task) => <TaskRow key={task.id} task={task} showProject />)}
          </div>
        ))}
    </div>
  )
}
