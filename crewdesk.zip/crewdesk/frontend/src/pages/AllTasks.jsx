import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { Plus, ListChecks } from 'lucide-react'
import { useData, useUi } from '../lib/ui-context'
import { qs } from '../lib/api'
import { Empty, Loading } from '../components/ui'
import TaskRow from '../components/TaskRow'

export default function AllTasks() {
  const { tid } = useParams()
  const { openTask, people, projects, setQuickAdd } = useUi()
  const [f, setF] = useState({ status: 'open', assignee: '', project_id: '', due: '', priority: '', q: '' })
  const { data } = useData(`/tasks${qs(f)}`, [JSON.stringify(f)])
  useEffect(() => { if (tid) openTask(+tid) }, [tid, openTask])
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  return (
    <div className="page">
      <div className="page-head"><h1>Tasks</h1><span className="muted">{data ? `${data.length} tasks` : ''}</span><span className="spacer" />
        <button className="btn primary" onClick={() => setQuickAdd('task')}><Plus size={16} />Add task</button></div>
      <div className="card card-body row" style={{ marginBottom: 16, flexWrap: 'wrap' }}>
        <input className="input" style={{ flex: '1 1 200px' }} placeholder="Search tasks" value={f.q} onChange={set('q')} />
        <select className="select" style={{ width: 150 }} value={f.status} onChange={set('status')}><option value="open">Open</option><option value="completed">Completed</option><option value="all">All</option></select>
        <select className="select" style={{ width: 170 }} value={f.assignee} onChange={set('assignee')}><option value="">Anyone</option><option value="me">Me</option><option value="none">Unassigned</option>{people.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        <select className="select" style={{ width: 190 }} value={f.project_id} onChange={set('project_id')}><option value="">All projects</option>{projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
        <select className="select" style={{ width: 150 }} value={f.due} onChange={set('due')}><option value="">Any date</option><option value="late">Late</option><option value="today">Today</option><option value="week">Next 7 days</option><option value="upcoming">Upcoming</option><option value="nodate">No due date</option></select>
        <select className="select" style={{ width: 140 }} value={f.priority} onChange={set('priority')}><option value="">Any priority</option><option value="high">High</option><option value="medium">Medium</option><option value="low">Low</option></select>
      </div>
      <div className="card">{!data ? <Loading /> : data.length === 0 ? <Empty icon={ListChecks} title="No matching tasks" /> : data.map((t) => <TaskRow key={t.id} task={t} showProject />)}</div>
    </div>
  )
}
