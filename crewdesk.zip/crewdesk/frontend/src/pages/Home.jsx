import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Clock, Inbox, ListChecks, Flag } from 'lucide-react'
import { useAuth } from '../lib/auth'
import { useData, useUi } from '../lib/ui-context'
import { fmtMinutes, HEALTH, timeAgo, fmtDate } from '../lib/format'
import { Bars, Donut, Empty, Loading, Avatar } from '../components/ui'
import TaskRow from '../components/TaskRow'

const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

export default function HomePage() {
  const { user } = useAuth()
  const [range, setRange] = useState(7)
  const { data } = useData(`/dashboard?range_days=${range}`, [range])
  const [tab, setTab] = useState('late')
  const hour = new Date().getHours()
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'

  if (!data) return <div className="page"><Loading /></div>
  const health = Object.entries(data.projects_by_health).filter(([, v]) => v > 0)
  const delegatedTabs = [['late', 'Late'], ['today', 'Today'], ['upcoming', 'Upcoming'], ['no_due_date', 'No due date'], ['completed', 'Completed']]
  const totalTime = data.time_distribution.reduce((a, b) => a + b.minutes, 0)

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="subtitle">{new Date().toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</div>
          <h1>{greet}, {user.name.split(' ')[0]}</h1>
        </div>
      </div>

      <div className="grid cols-4" style={{ marginBottom: 16 }}>
        <Link to="/my-work" className="card stat"><div className="num" style={{ color: 'var(--danger)' }}>{data.counts.my_late}</div><div className="lbl">My late tasks</div></Link>
        <Link to="/my-work" className="card stat"><div className="num" style={{ color: 'var(--warn)' }}>{data.counts.my_today}</div><div className="lbl">Due today</div></Link>
        <Link to="/my-work" className="card stat"><div className="num">{data.counts.my_open}</div><div className="lbl">Open tasks assigned to me</div></Link>
        <Link to="/time" className="card stat"><div className="num">{fmtMinutes(data.time_by_weekday.reduce((a, b) => a + b, 0))}</div><div className="lbl">Logged this week</div></Link>
      </div>

      <div className="grid cols-3">
        <div className="card">
          <div className="card-head"><Clock size={16} /><h3>Time distribution</h3><span className="spacer" />
            <select className="select" style={{ width: 'auto', padding: '3px 6px' }} value={range} onChange={(e) => setRange(+e.target.value)}>
              <option value={7}>Last 7 days</option><option value={30}>Last 30 days</option><option value={90}>Last 90 days</option>
            </select></div>
          <div className="card-body">
            {totalTime === 0 ? <Empty icon={Clock} title="No data just yet" text="Log time to see where it goes" /> : (
              <div className="row" style={{ alignItems: 'center', gap: 20 }}>
                <Donut items={data.time_distribution.map((t) => ({ value: t.minutes, color: t.color }))} center={fmtMinutes(totalTime)} />
                <div className="legend" style={{ flex: 1 }}>
                  {data.time_distribution.map((t) => <div className="li" key={t.name}><span className="dot" style={{ background: t.color }} />{t.name}<span className="v">{fmtMinutes(t.minutes)}</span></div>)}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-head"><ListChecks size={16} /><h3>Projects by health</h3></div>
          <div className="card-body">
            {health.length === 0 ? <Empty title="No active projects" /> : (
              <div className="row" style={{ alignItems: 'center', gap: 20 }}>
                <Donut items={health.map(([k, v]) => ({ value: v, color: HEALTH[k].color }))} />
                <div className="legend" style={{ flex: 1 }}>
                  {health.map(([k, v]) => <div className="li" key={k}><span className="dot" style={{ background: HEALTH[k].color }} />{HEALTH[k].label}<span className="v">{v}</span></div>)}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <div className="card-head"><Inbox size={16} /><h3>My unread items</h3><span className="spacer" /><Link to="/inbox" className="small" style={{ color: 'var(--accent)' }}>View inbox</Link></div>
          <div className="card-body" style={{ padding: data.unread.length ? 8 : 16 }}>
            {data.unread.length === 0 ? <Empty icon={Inbox} title="You're all caught up" /> : data.unread.map((n) => (
              <Link to={n.link || '/inbox'} key={n.id} className="row" style={{ padding: 8, borderRadius: 8 }}>
                <Avatar user={n.actor} size={26} />
                <span style={{ flex: 1 }} className="small">{n.message}</span>
                <span className="muted small">{timeAgo(n.created_at)}</span>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="grid cols-2" style={{ marginTop: 16 }}>
        <div className="card">
          <div className="card-head"><h3>Delegated tasks</h3><span className="muted small">Tasks you created for others</span></div>
          <div className="tabs" style={{ padding: '0 12px', marginBottom: 0 }}>
            {delegatedTabs.map(([k, l]) => <button key={k} className={`tab ${tab === k ? 'active' : ''}`} onClick={() => setTab(k)}>{l} <span className="badge grey">{data.delegated[k].length}</span></button>)}
          </div>
          <div style={{ maxHeight: 320, overflowY: 'auto' }}>
            {data.delegated[tab].length === 0 ? <Empty icon={ListChecks} title={`No ${delegatedTabs.find((d) => d[0] === tab)[1].toLowerCase()} tasks`} /> :
              data.delegated[tab].map((t) => <TaskRow key={t.id} task={t} showProject />)}
          </div>
        </div>
        <div className="grid" style={{ gap: 16 }}>
          <div className="card">
            <div className="card-head"><Clock size={16} /><h3>Logged time by weekday</h3><span className="muted small">This week</span></div>
            <div className="card-body"><Bars data={data.time_by_weekday} labels={DAYS} format={fmtMinutes} /></div>
          </div>
          <div className="card">
            <div className="card-head"><Flag size={16} /><h3>Upcoming milestones</h3><span className="spacer" /><Link to="/milestones" className="small" style={{ color: 'var(--accent)' }}>All</Link></div>
            <div>
              {data.milestones.length === 0 ? <Empty icon={Flag} title="No upcoming milestones" /> : data.milestones.map((m) => (
                <Link to={`/projects/${m.project_id}/milestones`} key={m.id} className="task-row"><Flag size={15} color="#8b5cf6" /><span className="title">{m.name}</span><span className="meta">{fmtDate(m.due_date)}</span></Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
