import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Plus, Star, Folder, LayoutGrid, List } from 'lucide-react'
import { api } from '../lib/api'
import { useData, useUi } from '../lib/ui-context'
import { fmtDate, fmtMinutes } from '../lib/format'
import { AvatarStack, Empty, HealthPill, Loading, Progress } from '../components/ui'

export function StarButton({ project }) {
  const { refresh } = useUi()
  return (
    <button className="icon-btn" title="Star" onClick={async (e) => { e.preventDefault(); e.stopPropagation(); await api.patch(`/projects/${project.id}`, { name: project.name, is_starred: !project.is_starred }); refresh() }}>
      <Star size={16} fill={project.is_starred ? '#f59e0b' : 'none'} color={project.is_starred ? '#f59e0b' : 'currentColor'} />
    </button>
  )
}

export default function Projects() {
  const { setQuickAdd } = useUi()
  const navigate = useNavigate()
  const [status, setStatus] = useState('active')
  const [q, setQ] = useState('')
  const [view, setView] = useState(() => localStorage.getItem('cd_pview') || 'table')
  const { data } = useData(`/projects?status=${status}`, [status])
  const setV = (v) => { localStorage.setItem('cd_pview', v); setView(v) }
  const items = (data || []).filter((p) => p.name.toLowerCase().includes(q.toLowerCase()))
  return (
    <div className="page">
      <div className="page-head">
        <h1>Projects</h1>
        <span className="spacer" />
        <input className="input" style={{ width: 220 }} placeholder="Filter projects" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="seg">
          {['active', 'completed', 'archived', 'all'].map((s) => <button key={s} className={status === s ? 'active' : ''} onClick={() => setStatus(s)}>{s[0].toUpperCase() + s.slice(1)}</button>)}
        </div>
        <div className="seg">
          <button className={view === 'table' ? 'active' : ''} onClick={() => setV('table')}><List size={15} /></button>
          <button className={view === 'cards' ? 'active' : ''} onClick={() => setV('cards')}><LayoutGrid size={15} /></button>
        </div>
        <button className="btn primary" onClick={() => setQuickAdd('project')}><Plus size={16} />Add project</button>
      </div>
      {!data ? <Loading /> : items.length === 0 ? <div className="card"><Empty icon={Folder} title="No projects" action={<button className="btn primary" onClick={() => setQuickAdd('project')}>Create a project</button>} /></div> :
        view === 'cards' ? (
          <div className="grid cols-3">
            {items.map((p) => (
              <Link to={`/projects/${p.id}`} key={p.id} className="card" style={{ borderTop: `4px solid ${p.color}` }}>
                <div className="card-body">
                  <div className="row"><h3 className="ellipsis" style={{ flex: 1 }}>{p.name}</h3><StarButton project={p} /></div>
                  <div className="muted small" style={{ margin: '4px 0 12px', minHeight: 18 }}>{p.client?.name || 'No client'}</div>
                  <Progress value={p.progress} />
                  <div className="row small muted" style={{ marginTop: 8 }}>
                    <span>{p.completed_count}/{p.task_count} tasks</span>
                    {p.late_count > 0 && <span style={{ color: 'var(--danger)' }}>{p.late_count} late</span>}
                    <span style={{ flex: 1 }} /><HealthPill h={p.health} />
                  </div>
                  <div className="row" style={{ marginTop: 12 }}><AvatarStack users={p.members} /><span style={{ flex: 1 }} /><span className="small muted">{p.end_date ? `Due ${fmtDate(p.end_date)}` : ''}</span></div>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <div className="card" style={{ overflowX: 'auto' }}>
            <table className="table">
              <thead><tr><th style={{ width: 40 }} /><th>Project</th><th>Client</th><th>Health</th><th style={{ width: 160 }}>Progress</th><th>Late</th><th>Time logged</th><th>End date</th><th>Owner</th><th>People</th></tr></thead>
              <tbody>
                {items.map((p) => (
                  <tr key={p.id} className="click" onClick={() => navigate(`/projects/${p.id}`)}>
                    <td><StarButton project={p} /></td>
                    <td><span className="row"><span className="dot" style={{ background: p.color, width: 10, height: 10 }} /><b>{p.name}</b></span></td>
                    <td className="muted">{p.client?.name || '—'}</td>
                    <td><HealthPill h={p.health} /></td>
                    <td><div className="row"><div style={{ flex: 1 }}><Progress value={p.progress} /></div><span className="small muted">{p.progress}%</span></div></td>
                    <td>{p.late_count > 0 ? <span className="badge red">{p.late_count}</span> : <span className="muted">0</span>}</td>
                    <td>{fmtMinutes(p.logged_minutes)}</td>
                    <td className="muted">{fmtDate(p.end_date) || '—'}</td>
                    <td>{p.owner?.name || '—'}</td>
                    <td><AvatarStack users={p.members} size={24} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
    </div>
  )
}
