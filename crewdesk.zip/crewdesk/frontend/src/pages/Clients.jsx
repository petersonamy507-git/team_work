import { useState } from 'react'
import { Plus, Building2, Pencil, Trash2 } from 'lucide-react'
import { api } from '../lib/api'
import { useData, useUi } from '../lib/ui-context'
import { Empty, Loading, Modal } from '../components/ui'

function ClientForm({ client, onClose }) {
  const { refresh } = useUi()
  const [f, setF] = useState({ name: client?.name || '', website: client?.website || '', email: client?.email || '', phone: client?.phone || '' })
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })
  const submit = async () => {
    if (!f.name.trim()) return
    client ? await api.patch(`/clients/${client.id}`, f) : await api.post('/clients', f)
    refresh(); onClose()
  }
  return (
    <Modal title={client ? 'Edit client' : 'Add client'} onClose={onClose} footer={<><button className="btn" onClick={onClose}>Cancel</button><button className="btn primary" onClick={submit}>Save</button></>}>
      <div className="field"><label>Company name</label><input className="input" autoFocus value={f.name} onChange={set('name')} /></div>
      <div className="field"><label>Website</label><input className="input" value={f.website} onChange={set('website')} /></div>
      <div className="row"><div className="field"><label>Email</label><input className="input" value={f.email} onChange={set('email')} /></div>
        <div className="field"><label>Phone</label><input className="input" value={f.phone} onChange={set('phone')} /></div></div>
    </Modal>
  )
}

export default function Clients() {
  const { refresh } = useUi()
  const { data } = useData('/clients')
  const [form, setForm] = useState(null)
  const del = async (c) => { if (confirm(`Delete client ${c.name}? Projects keep existing without a client.`)) { await api.del(`/clients/${c.id}`); refresh() } }
  return (
    <div className="page">
      <div className="page-head"><h1>Clients</h1><span className="spacer" /><button className="btn primary" onClick={() => setForm({})}><Plus size={16} />Add client</button></div>
      <div className="card">
        {!data ? <Loading /> : data.length === 0 ? <Empty icon={Building2} title="No clients yet" /> : (
          <table className="table">
            <thead><tr><th>Client</th><th>Website</th><th>Email</th><th>Phone</th><th>Projects</th><th /></tr></thead>
            <tbody>{data.map((c) => (
              <tr key={c.id}><td><span className="row"><Building2 size={16} className="muted" /><b>{c.name}</b></span></td>
                <td>{c.website ? <a href={c.website} target="_blank" rel="noreferrer" style={{ color: 'var(--accent)' }}>{c.website}</a> : '—'}</td>
                <td>{c.email || '—'}</td><td>{c.phone || '—'}</td><td>{c.project_count}</td>
                <td style={{ textAlign: 'right' }}><button className="icon-btn" onClick={() => setForm(c)}><Pencil size={15} /></button><button className="icon-btn" onClick={() => del(c)}><Trash2 size={15} /></button></td></tr>))}</tbody>
          </table>)}
      </div>
      {form && <ClientForm client={form.id ? form : null} onClose={() => setForm(null)} />}
    </div>
  )
}
