import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Inbox, CheckCheck, Circle } from 'lucide-react'
import { api } from '../lib/api'
import { useData, useUi } from '../lib/ui-context'
import { timeAgo } from '../lib/format'
import { Avatar, Empty, Loading } from '../components/ui'

export default function InboxPage() {
  const [filter, setFilter] = useState('all')
  const { refresh } = useUi()
  const navigate = useNavigate()
  const { data } = useData(`/inbox?filter=${filter}`, [filter])
  if (!data) return <div className="page"><Loading /></div>
  const open = async (n) => {
    if (!n.is_read) await api.post(`/inbox/${n.id}/read`)
    refresh()
    if (n.link) navigate(n.link)
  }
  return (
    <div className="page" style={{ maxWidth: 900 }}>
      <div className="page-head">
        <h1>Inbox</h1>{data.unread > 0 && <span className="badge red">{data.unread} unread</span>}
        <span className="spacer" />
        <div className="seg">
          <button className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>All</button>
          <button className={filter === 'unread' ? 'active' : ''} onClick={() => setFilter('unread')}>Unread</button>
        </div>
        <button className="btn" onClick={async () => { await api.post('/inbox/read-all'); refresh() }}><CheckCheck size={16} />Mark all read</button>
      </div>
      <div className="card">
        {data.items.length === 0 ? <Empty icon={Inbox} title="Your inbox is empty" text="Assignments, comments and messages land here" /> : data.items.map((n) => (
          <div key={n.id} className="task-row" style={{ cursor: 'pointer', background: n.is_read ? undefined : '#f7f8ff' }} onClick={() => open(n)}>
            <Avatar user={n.actor} />
            <span className="title" style={{ fontWeight: n.is_read ? 400 : 600 }}>{n.message}</span>
            <span className="meta">{timeAgo(n.created_at)}
              <button className="icon-btn" title={n.is_read ? 'Mark unread' : 'Mark read'} onClick={async (e) => { e.stopPropagation(); await api.post(`/inbox/${n.id}/read?read=${!n.is_read}`); refresh() }}>
                <Circle size={10} fill={n.is_read ? 'none' : 'var(--accent)'} color="var(--accent)" />
              </button>
            </span>
          </div>
        ))}
      </div>
    </div>
  )
}
