import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useData, useUi } from '../lib/ui-context'

const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

export default function CalendarPage() {
  const { openTask } = useUi()
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1) })
  const [mine, setMine] = useState(false)
  const start = new Date(month); start.setDate(1 - ((month.getDay() + 6) % 7))
  const days = Array.from({ length: 42 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d })
  const { data } = useData(`/calendar?start=${iso(days[0])}&end=${iso(days[41])}&mine=${mine}`, [month, mine])
  const today = iso(new Date())
  const shift = (n) => setMonth(new Date(month.getFullYear(), month.getMonth() + n, 1))
  return (
    <div className="page">
      <div className="page-head">
        <h1>{month.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</h1>
        <button className="icon-btn" onClick={() => shift(-1)}><ChevronLeft size={18} /></button>
        <button className="icon-btn" onClick={() => shift(1)}><ChevronRight size={18} /></button>
        <button className="btn sm" onClick={() => { const d = new Date(); setMonth(new Date(d.getFullYear(), d.getMonth(), 1)) }}>Today</button>
        <span className="spacer" />
        <div className="seg"><button className={!mine ? 'active' : ''} onClick={() => setMine(false)}>Everyone</button><button className={mine ? 'active' : ''} onClick={() => setMine(true)}>Just me</button></div>
      </div>
      <div className="cal">
        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => <div className="dh" key={d}>{d}</div>)}
        {days.map((d) => {
          const k = iso(d)
          const tasks = data?.tasks.filter((t) => t.due_date === k) || []
          const ms = data?.milestones.filter((m) => m.due_date === k) || []
          return (
            <div key={k} className={`day ${d.getMonth() !== month.getMonth() ? 'other' : ''} ${k === today ? 'today' : ''}`}>
              <span className="n">{d.getDate()}</span>
              {ms.map((m) => <span key={'m' + m.id} className="ev" style={{ background: '#8b5cf6' }}>⚑ {m.name}</span>)}
              {tasks.slice(0, 4).map((t) => <span key={t.id} className="ev" onClick={() => openTask(t.id)} style={{ background: t.status === 'completed' ? '#94a3b8' : k < today ? '#ef4444' : '#6366f1' }}>{t.title}</span>)}
              {tasks.length > 4 && <span className="muted">+{tasks.length - 4} more</span>}
            </div>
          )
        })}
      </div>
    </div>
  )
}
